package controller;
/**
AUTHOR@author Sheckardo Daley
*/


import java.util.ArrayList;

import model.Farmer;



public class FarmController  {

	public Farmer farmer = new Farmer ();
	
	
	public void save(ArrayList<Farmer> u) {
		
	farmer.saveFarmer(u);
	}

	
	public ArrayList<Farmer> RetrieveUsers() {
		ArrayList<Farmer> f = farmer.getFarmers();

	return f;
	}

	


	public boolean UserExists() {

	boolean result =	farmer.UserFileExists()?  true :  false;
	
	return result;
	}

	public boolean loginCheck(String email, String password) {
		boolean result = farmer.FarmerloginCheck(email, password)? true : false ;

		return result;
			
		}

	
}
