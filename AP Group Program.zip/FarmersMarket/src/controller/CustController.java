package controller;
/**
AUTHOR@author Sheckardo Daley
*/


import java.util.ArrayList;


import model.User;

public class CustController {

	private User cust = new User ();

	public ArrayList<User> retreiveUsers() {
		ArrayList<User> res = cust.getUsers();
	
		return res;
		
	}


	public void save(ArrayList<User> u) {
		cust.saveCust(u);
		
	}

	
	public boolean UserFileExists() {
	
		boolean result =	cust.UserFileExists()?  true :  false;
		
		return result;
	}





public boolean loginCheck(String email, String password) {
boolean result = cust.CustloginCheck(email, password)? true : false ;

return result;
	
}

}