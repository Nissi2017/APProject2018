package model;
/**
AUTHOR@author Sheckardo Daley
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.Icon;


@SuppressWarnings("serial")
public class User implements Serializable{

	protected String fname;
	protected String lname ;
	protected String email;
	protected String password;
	protected Icon img ;
	
	public User () {
		fname = "Blank first name";
		lname = "Blank last name";
		email = "Blank email";
		password = "Blank password";
	}
	
	public User (String inFname, String inLname, String inEmail, String inPassword,Icon Inimg) {
	
		fname = inFname;
		lname = inLname;
		email = inEmail;
		password = inPassword;
		img = Inimg;
	}
	
	public User (User inUser) {
		fname = inUser.fname;
		lname = inUser.lname;
		email = inUser.email;
		password = inUser.password;
	img = inUser.img;
	}
	
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public String getEmail() {
		return email;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Icon getImg() {
		return img;
	}
	public void setImg(Icon img) {
		this.img = img;
	}
	public void display () {
		System.out.println("\n" + fname + " " + lname);
		System.out.println(email);
		System.out.println(password);
	}	
	
	
	public ArrayList<User> getUsers() {
		UserFileExists();
		ArrayList<User> c= new ArrayList<User>();
		ObjectInputStream ois = null;

		try {
			try {
			FileInputStream fis = new FileInputStream("customers.dat");
			ois = new ObjectInputStream(fis);
			} catch(FileNotFoundException fe) {
				fe.printStackTrace();
			}
			try {
				
			c = (ArrayList<User>)ois.readObject(); //ARRAY IS RECEIVED AND CONVERTED TO ARRAY OF FARMERS
			} catch (ClassCastException | ClassNotFoundException ce) {
				ce.printStackTrace();
			}
			
		}catch (IOException e) {
		
			e.printStackTrace();
		}
		
		finally {
			try { if (ois != null)
				ois.close();
		
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
			return c;
	
		
	}


	public void saveCust(ArrayList<User> u) {
		UserFileExists();
		ObjectOutputStream oos = null;

		try {
			FileOutputStream fos = new FileOutputStream("customers.dat");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(u);
			
			System.out.println("Object Saved");
		}catch (IOException e) {
		
			e.printStackTrace();
		}
		
		finally {
			try { if (oos != null)
				oos.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
	}

	
	public boolean UserFileExists() {
	
		File yourFile = new File("customers.dat");
		 // if file already exists will do nothing 
	
		if(yourFile.exists() == false) {
			try {
			yourFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(yourFile, false); 
			fos.close();		
			return false;
			} catch (IOException e) {
			e.printStackTrace();	
				}
			} else {
				return true;
			}
	return true;
	}




public boolean CustloginCheck(String email, String password) {
	ArrayList<User> alf = getUsers();

	for (int d = 0; d < alf.size(); d++) {
		if (alf.get(d).getEmail().equals(email) && alf.get(d).getPassword().equals(password)) {
		return true;
		}
	}
	return false;
}
	
	
}
