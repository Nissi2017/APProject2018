package mainDriver;

/**
AUTHOR@author Sheckardo Daley
*/

import java.awt.EventQueue;

import controller.CustController;
import controller.FarmController;
import view.GUI;


public class Driver {
	
	public static void main(String[] args) {

		
		EventQueue.invokeLater(new Runnable() {

			public void run() {
					new GUI( new CustController() , new FarmController ());
				
				
			}
		}

							);
	
	

	}
	
	



}
