import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MyServer {
    public MyServer()throws Exception{
        System.setProperty("java.rmi.server.hostname", "127.0.0.1");
        Registry reg = LocateRegistry.createRegistry(8050);
        Remote r = new RemoteImpl();
        reg.rebind("server",r);
        ServerFrame.setLogging("RMI Server Started at port 8050");
    }
}