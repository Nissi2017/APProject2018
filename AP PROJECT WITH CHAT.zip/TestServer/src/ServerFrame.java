import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ServerFrame extends JFrame {

	private JPanel contentPane;
	private static JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ServerFrame frame = new ServerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				ChatServer.startServer();
			}
		}).run();
	}

	/**
	 * Create the frame.
	 */
	public ServerFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 595, 396);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("MAIN SERVER");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblNewLabel.setBounds(221, 11, 151, 28);
		contentPane.add(lblNewLabel);

		 textArea = new JTextArea();
		textArea.setBounds(10, 84, 559, 263);
		contentPane.add(textArea);

		JButton btnStartServer = new JButton("START SERVER");
		btnStartServer.setBounds(190, 50, 147, 23);
		contentPane.add(btnStartServer);

		JButton btnStopServer = new JButton("STOP SERVER");
		btnStopServer.setBounds(344, 50, 147, 23);
		contentPane.add(btnStopServer);

		btnStartServer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							new MyServer();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}).start();

			}
		});

		btnStopServer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
	}


	public static void setLogging(String log){
		textArea.append(log);
	}
}
