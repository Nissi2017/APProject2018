import javax.swing.table.DefaultTableModel;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RemoteImpl extends UnicastRemoteObject implements RemoteInterface {

    private static Connection con;

    public RemoteImpl()throws RemoteException{

    }


    @Override
    public int checkIfCustomerExists(String email, String password) throws RemoteException {
        PreparedStatement ps = null;
        con = DbConnect.getDbConnect();
        try {
            ps = con.prepareStatement("select * from customer WHERE Email = '"+email+"' AND password = '"+password+"'");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int clientId = rs.getInt(1);
               ServerFrame.setLogging("\nLogged in Successfully..");
                return clientId;
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    @Override
    public int checkIfFarmerExists(String email, String password) throws RemoteException {
        PreparedStatement ps = null;
        con = DbConnect.getDbConnect();
        try {
            ps = con.prepareStatement("select * from farmer WHERE email = '"+email+"' AND password = '"+password+"'");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int clientId = rs.getInt(1);
                ServerFrame.setLogging("\nLogged in Farmer Successfully..");
                return clientId;
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public Boolean registerFarmer(Farmer newFarmer) throws RemoteException {

        String SQL1 = "INSERT INTO `farmer`( `fName`,`lName`, `email`, `password`, `address`, `earnings`, `sellerLevel`) VALUES(?,?,?,?,?,?)";

        try {

            con = new DbConnect().getDbConnect();
            PreparedStatement preparedStatement1 = new DbConnect().getDbConnect().prepareStatement(SQL1);
            preparedStatement1.setString(1, newFarmer.getFname());
            preparedStatement1.setString(2, newFarmer.getLname());
            preparedStatement1.setString(3, newFarmer.getEmail());
            preparedStatement1.setString(4, newFarmer.getPassword());
            preparedStatement1.setString(5, newFarmer.getAddress());
            preparedStatement1.setFloat(6, 0);
            preparedStatement1.setString(7, "1");
            preparedStatement1.execute();
            System.out.println("Inserted New Farmer");
            ServerFrame.setLogging("\nInserted New Farmer");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Boolean registerCustomer(User newCust) throws RemoteException {
        String SQL1 = "INSERT INTO `customer`( `fullName`, `Email`, `password`, `address`, `balance`) VALUES(?,?,?,?,?)";

        try {

            con = new DbConnect().getDbConnect();
            PreparedStatement preparedStatement1 = new DbConnect().getDbConnect().prepareStatement(SQL1);
            preparedStatement1.setString(1, newCust.getFname()+" "+newCust.getLname());
            preparedStatement1.setString(2, newCust.getEmail());
            preparedStatement1.setString(3, newCust.getPassword());
            preparedStatement1.setString(4, "");
            preparedStatement1.setFloat(5, 0);
            preparedStatement1.execute();
            System.out.println("Inserted New Customer");
            ServerFrame.setLogging("\nInserted New Customer");

            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Boolean addCrop(Crop crop) throws RemoteException {
        String SQL1 = "INSERT INTO `crops`( `name`, `farmerID`, `quantiy`, `price`) VALUES(?,?,?,?)";

        try {

            con = new DbConnect().getDbConnect();
            PreparedStatement preparedStatement1 = new DbConnect().getDbConnect().prepareStatement(SQL1);
            preparedStatement1.setString(1, crop.getName());
            preparedStatement1.setInt(2, crop.getFarmerID());
            preparedStatement1.setInt(3, crop.getQuantity());
            preparedStatement1.setFloat(4, crop.getCost());
            preparedStatement1.execute();
            System.out.println("Inserted Crop");
            ServerFrame.setLogging("\nInserted New Crop");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Boolean updateCrop(Crop crop) throws RemoteException {
        String SQL1 = "UPDATE `crops` SET `farmerID` = ?, `quantiy` = ?, `price` = ? WHERE farmerID = ? AND name = ?";

        try {

            con = new DbConnect().getDbConnect();
            PreparedStatement preparedStatement1 = new DbConnect().getDbConnect().prepareStatement(SQL1);
            preparedStatement1.setInt(1, crop.getFarmerID());
            preparedStatement1.setInt(2, crop.getQuantity());
            preparedStatement1.setFloat(3, crop.getCost());
            preparedStatement1.setInt(4,1);
            preparedStatement1.setString(5, crop.getName());
            preparedStatement1.execute();
            System.out.println("Update Crop");
            ServerFrame.setLogging("\nUpdated Crop");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public DefaultTableModel viewAllCrops() throws RemoteException {

        System.out.println("Retrieving all crops...");
        ServerFrame.setLogging("\nRetrieving all crops...");
        DefaultTableModel model = new DefaultTableModel ();
        model.addColumn("Crop ID");
        model.addColumn("Name");
        model.addColumn("Quantity");
        model.addColumn("Price");
        try{
            con = new DbConnect().getDbConnect();
            PreparedStatement pst = con.prepareStatement("SELECT * FROM crops;");
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)});
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return model;
    }

    @Override
    public DefaultTableModel viewAllFarmerCropsByID(int farmerId) throws RemoteException {

        ServerFrame.setLogging("\nRetrieving Fammer crops... ID "+farmerId);
        System.out.println("\nRetrieving Fammer crops... ID "+farmerId);
        DefaultTableModel model = new DefaultTableModel ();
        model.addColumn("Crop ID");
        model.addColumn("Name");
        model.addColumn("Quantity");
        model.addColumn("Price");
        try{
            con = new DbConnect().getDbConnect();
            PreparedStatement pst = con.prepareStatement("SELECT * FROM crops where farmerID = ?;");
            pst.setInt(1,farmerId);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)});
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return model;
    }

    @Override
    public  Farmer getFarmerDetails(int farmerId) throws RemoteException {

        System.out.println("Retrieving Farmer Details ...");
        ServerFrame.setLogging("\nRetrieving Farmer Details ...");

        try{
            con = new DbConnect().getDbConnect();
            PreparedStatement pst = con.prepareStatement("SELECT * FROM farmer WHERE `farmerID` = "+farmerId+" ");
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                Farmer farmer = new Farmer(rs.getString(2),rs.getString(3),rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),null);
                System.out.println("Retrieved Farmer");
                return farmer;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public User getUserDetails(int customerID) throws RemoteException {

        System.out.println("Retrieving Customer Details ...");
        ServerFrame.setLogging("\nRetrieving Customer Details ...");

        try{
            con = new DbConnect().getDbConnect();
            PreparedStatement pst = con.prepareStatement("SELECT * FROM customer WHERE `clientID` = "+customerID+" ");
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                return new User(rs.getString(2), rs.getString(3),rs.getString(5),null);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return null;
    }

}