import javax.swing.*;
import java.io.File;


public class JDesktop extends javax.swing.JDesktopPane
{ /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
String PHOTO_DIR = System.getProperty("user.dir") + File.separator + "photos" + File.separator;
String farmimg = "backImage.jpg";
String farmwindowPath = PHOTO_DIR+farmimg ;
 
   
   public JDesktop()
   {     
 
      ImageIcon icon = new ImageIcon((farmwindowPath));
 		 JLabel label = new JLabel(icon);
 		 label.setBounds(0, 0, icon.getIconWidth(), icon.getIconHeight());
    
 		 super.add(label, new Integer(Integer.MIN_VALUE));
   }
 



}