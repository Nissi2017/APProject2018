import javax.swing.*;


public class MainThread implements Runnable{

	@Override
	public synchronized void run() {
	
		GUI desktopFrame = new GUI( new CustController());
		desktopFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		desktopFrame.setSize(840, 670); // set frame size
		desktopFrame.setVisible(true); // display frame
	}
	public static void main(String[] args) {

	Thread t = new Thread(new MainThread());	
	t.start();
	
	}
}
