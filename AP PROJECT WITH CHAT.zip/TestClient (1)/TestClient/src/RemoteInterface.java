import javax.swing.table.DefaultTableModel;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by Roberto Delfosse on 3/21/2018.
 */

interface RemoteInterface extends Remote{
     int checkIfCustomerExists(String email, String password)throws RemoteException;
     int checkIfFarmerExists(String email, String password)throws RemoteException;
     Boolean registerFarmer(Farmer newFarmer) throws  RemoteException;
     Boolean registerCustomer(User newCust) throws RemoteException;
     Boolean addCrop(Crop crop) throws RemoteException;
     Boolean updateCrop(Crop crop) throws RemoteException;
     DefaultTableModel viewAllCrops() throws RemoteException;
    DefaultTableModel viewAllFarmerCropsByID(int farmerID) throws RemoteException;
    Farmer getFarmerDetails(int farmerID) throws RemoteException;
     User getUserDetails(int customerID) throws RemoteException;
}