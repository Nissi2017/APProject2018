import javax.swing.*;
import java.io.Serializable;

public class Crop implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private float weight;
	private float cost;
	private String avail ;
	private int quantity;
	private Icon img;

	public int getFarmerID() {
		return farmerID;
	}

	public void setFarmerID(int farmerID) {
		this.farmerID = farmerID;
	}

	private int farmerID;
	
	public Crop () {
		name = "Blank crop name";
		weight = 0.0f ;
		cost = 0.0f;
		avail = "Blank availability";
		quantity = 0;
		img = null;
	}
	
	
	
	public Crop(int farmerID,String name, float weight, float cost, int quantity, Icon img) {
		this.name = name;
		this.weight = weight;
		this.cost = cost;
		this.avail = "Yes";
		this.quantity = quantity;
		this.img = img;
		this.farmerID = farmerID;
	}

	public Crop (Crop inCrop) {
		name = inCrop.name;
		weight = inCrop.weight;
		cost = inCrop.cost;
		avail = inCrop.avail;
		quantity = inCrop.quantity;
		img = inCrop.img;
	}


	public String getName() {
		return name;
	}
	public float getWeight() {
		return weight;
	}
	public float getCost() {
		return cost;
	}
	public String getAvail() {
		return avail;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public void setAvail(String avail) {
		this.avail = avail;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public Icon getImg() {
		return img;
	}
	public void setImg(Icon img) {
		this.img = img;
	}
	public void display () {
		System.out.println(name);
		System.out.println(weight + " "+ "lbs");
		System.out.println("$"+cost);
		System.out.println(avail);
		System.out.println(quantity);
	}	



}
