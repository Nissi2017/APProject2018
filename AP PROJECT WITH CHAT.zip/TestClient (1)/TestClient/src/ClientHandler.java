import javax.swing.table.DefaultTableModel;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Created by Roberto Delfosse on 3/20/2018.
 */
public class ClientHandler {

    private RemoteInterface remote;

    public static void main(String args[])throws Exception{
        System.out.println(new ClientHandler().viewAllCrops());
    }

    public ClientHandler() throws RemoteException, NotBoundException, MalformedURLException {
        System.setProperty("java.rmi.server.hostname", "127.0.0.1");
        remote = (RemoteInterface) Naming.lookup("rmi://localhost:8050/server");
    }

    public int customerLoginCheck(String email, String password) {
        int userExists = -1;
        try {
            userExists = remote.checkIfCustomerExists(email,password);
            return  userExists;

        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return  userExists;
    }
    public int farmerLoginCheck(String email, String password) {
        int userExists = -1;
        try {
            userExists = remote.checkIfFarmerExists(email,password);
            return  userExists;

        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return  userExists;
    }

    public boolean registerFarmer(Farmer newFarmer) {
        try {
           Boolean success = remote.registerFarmer(newFarmer);
            return  success;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean registerCustomer(User newCust) {
        try {
            Boolean success = remote.registerCustomer(newCust);
            return  success;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean addCrop(Crop crop) {
        try {
            Boolean success = remote.addCrop(crop);
            return  success;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return false;
    }


    public DefaultTableModel viewAllCrops(){
        try {
            return remote.viewAllCrops();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return null;
    }
    public DefaultTableModel viewAllFarmerCrops(int farmerID){
        try {
            return remote.viewAllFarmerCropsByID(farmerID);
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return null;
    }
    public boolean updateCrop(Crop crop) {
        try {
            Boolean success = remote.updateCrop(crop);
            return  success;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return false;
    }
    public Farmer getFarmer(int farmerId) {
        try {
            return remote.getFarmerDetails(farmerId);
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return null;
    }
    public User getCustomer(int clientID) {
        try {
           return remote.getUserDetails(clientID);
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return null;
    }
}