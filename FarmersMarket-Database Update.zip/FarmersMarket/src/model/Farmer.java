package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.Icon;

import database.FarmerConnect;
@SuppressWarnings("serial")
public class Farmer extends User implements Serializable{
	
	FarmerConnect connect = new FarmerConnect();

	private String address;
	
	public Farmer () {
		super();
		address = "Blank address";	
	}

	public Farmer(String fname, String lname, String email,String password, String addy, Icon img) {
		
		super(fname,lname,email,password,img);
		address = addy ;

	
	}

	public Farmer(Farmer inFarmer) {
		address = inFarmer.address;
		fname = inFarmer.fname;
		lname = inFarmer.lname;
		email = inFarmer.email;
		password = inFarmer.password;
		img = inFarmer.img;
	}
	

	

	
public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Farmer getFarmers() {
	boolean res =	UserFileExists();
	
	if (res == true) {
		Farmer f= new Farmer();
		ObjectInputStream ois = null;

		try {
			try {
			FileInputStream fis = new FileInputStream("farmers.dat");
			ois = new ObjectInputStream(fis);
			} catch(FileNotFoundException fe) {
				fe.printStackTrace();
			}
			try {
				
			f = (Farmer)ois.readObject(); //ARRAY IS RECEIVED AND CONVERTED TO ARRAY OF FARMERS
			} catch (ClassCastException | ClassNotFoundException ce) {
				ce.printStackTrace();
			}
			
		}catch (IOException e) {
		
			e.printStackTrace();
		}
		
		finally {
			try { if (ois != null)
				ois.close();
		
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
			return f;
	} else {
		
	}
	Farmer farmers = new Farmer ();
	return farmers ;
	}
	
	public boolean saveFarmer(Farmer newFarmer) {
		
			return connect.userAdd(newFarmer);

		
		/*UserFileExists();
		ObjectOutputStream oos = null;

		try {
			FileOutputStream fos = new FileOutputStream("farmers.dat");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(u);
			
			System.out.println("Object Saved");
		}catch (IOException e) {
		
			e.printStackTrace();
		}
		
		finally {
			try { if (oos != null)
				oos.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}	*/
	
	}
	
	public boolean UserFileExists() {

		File yourFile = new File("farmers.dat");
		 // if file already exists will do nothing 
	
		if(yourFile.exists() == false) {
			try {
			yourFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(yourFile, false); 
			fos.close();		
			return false;
			} catch (IOException e) {
			e.printStackTrace();	
				}
			} else {
				return true;
			}
	return true;
	}

	/*public boolean FarmerloginCheck(String email, String password) {
		ArrayList<Farmer> alf = getFarmers();

		for (int d = 0; d < alf.size(); d++) {
			if (alf.get(d).getEmail().equals(email) && alf.get(d).getPassword().equals(password)) {
			return true;
			}
		}
		return false;
	}*/
	
	public boolean FarmerloginCheck(String email, String password){
		//try {
			
		return connect.loginVerify(email, password);
		
		//}catch(SQLException e) {
		//	e.printStackTrace();
			//System.out.println("Login Failed!");
			//logger.debug("Incorrect Login information");
		//	return false;
		//}
		
		
	}
	
	
public void display () {
	System.out.println("\n" + fname + " " + lname);
	System.out.println(email);
	System.out.println(password);
	System.out.println(address);
}

public void add(Farmer newFarmer) {
	// TODO Auto-generated method stub
	
}	
}
