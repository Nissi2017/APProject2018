package controller;
/**
AUTHOR@author Sheckardo Daley
*/


import java.io.Serializable;
import java.util.ArrayList;

import model.Farmer;



public class FarmController implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Farmer farmer = new Farmer ();
	
	
	public boolean save(Farmer newFarmers) {
		
	return farmer.saveFarmer(newFarmers);
	}
	

	
	public Farmer RetrieveUsers() {
		Farmer f = farmer.getFarmers();

	return f;
	}

	


	public boolean UserExists() {

	boolean result =	farmer.UserFileExists()?  true :  false;
	
	return result;
	}

	public boolean loginCheck(String email, String password) {
		boolean result = farmer.FarmerloginCheck(email, password)? true : false ;

		return result;
			
		}

	
}
