package view;
/**
AUTHOR@author Sheckardo Daley
*/



import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;

import java.awt.Font;

import java.awt.Image;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.JTextField;
import javax.swing.UIManager;
import controller.CustController;
import controller.FarmController;
import model.Farmer;
import model.User;


public class GUI extends JFrame  implements ActionListener{

	//LOG IN SCREEN
	private static final long serialVersionUID = 1L;
	private JInternalFrame contentPane = new JInternalFrame("Login", true, false,true,true);

	private JTextField emailField ;
	private JTextField passField ;
	private JComboBox<String> userSelect ;
	private JButton submit ;
	private JButton exitout;
	private CustController cc = new CustController();
	private FarmController fc = new FarmController();
	private JButton register;
//USER CREATION
	private JInternalFrame UserCreate = new JInternalFrame("Create User", true, true,true,true);
	private JTextField fname;
	private JTextField lname;
	private JTextField email;
	private JTextField address;
	private JRadioButton custRadio = new JRadioButton("Customer");
	private JRadioButton farmerRadio = new JRadioButton("Farmer",true);
	private JButton btnClear = new JButton("Reset");
	private JLabel avatar;
	private JTextField pword;

	
// CUSTOMER DASHBOARD
	private JButton cartbutton = new JButton();
	private JMenuBar menuBarC = new JMenuBar();
	private JMenu addFunds = new JMenu("Add Funds");
	private JInternalFrame profilePanelC = new JInternalFrame("Profile Page",true, true,true,true);
	private  JInternalFrame allCropsPanelC = new JInternalFrame("All Crops",true, true,true,true);
	private JInternalFrame contentPanelC = new JInternalFrame("Customer Dashboard",true, true,true,true);
	private JLabel prPicC = new JLabel("");
	private JTextField fullnameC = new JTextField();
	private JLabel fullnameCL = new JLabel("Full Name");
	private  JLabel emailCLC = new JLabel("Email");
	private  JTextField emailC = new JTextField();
	private  JLabel totalCLC = new JLabel("Balance");
	private  JTextField totalC = new JTextField();
	private JMenu ManageCropsC = new JMenu("Manage Crops");
	private JMenuItem ViewAllC = new JMenuItem("View All Crops");
	private JMenuItem mntmViewProfileC = new JMenuItem("View Profile");
	private JMenu mnProfileC = new JMenu("Profile");
	private JMenuItem mntmLiveChat = new JMenuItem("Start Live Chat");
	private JMenu mnLiveChat = new JMenu("Live Chat");
	
	private JMenuItem ViewSomeC = new JMenuItem("View Crops By Farmer");
	private JMenu mnExitC = new JMenu("Exit");
	private JMenuItem mntmLogoutC = new JMenuItem("Logout");

// FARMER DASHBOARD
	private JInternalFrame farmwindow = new JInternalFrame("Farmer Page", true, true,true,true);
	private JMenuBar menuBar = new JMenuBar();
	private JMenu mnManageCrops = new JMenu("Manage Crops");
	private JMenu mnProfile = new JMenu("Profile");
	private JMenu mnExit = new JMenu("Exit");
	private JMenu mnSales = new JMenu("Sales");
	private JMenuItem mntmSalesMade = new JMenuItem("Sales Made");
	private JMenuItem mntmAddCrop = new JMenuItem("Add Crop");
	private JMenuItem mntmUpdateCrop = new JMenuItem("Update Crop");
	private JMenuItem mntmViewAllCrops = new JMenuItem("View All Crops");
	private JMenuItem mntmViewProfile = new JMenuItem("View Profile");
	private JMenuItem mntmLogout = new JMenuItem("Logout");
	private JLabel cNameL = new JLabel("Crop Name");
	private JTextField cName = new JTextField();
	private JTextField cWeight = new JTextField();
	private JLabel cWeightL = new JLabel("Weight");
	private JTextField cCost = new JTextField();
	private JLabel cCostL = new JLabel("Cost");
	private JLabel cQuanL = new JLabel("Quantity");
	private JTextField cQuan = new JTextField();
	private JButton cBtnImg = new JButton("Add Image");
	private JButton cBtnSave = new JButton("Save");
	private JLabel cPic = new JLabel("");
	private JLabel prPic = new JLabel("");
	private JTextField fullname = new JTextField();
	private JLabel fullnameL = new JLabel("Full Name");
	private JLabel addrL = new JLabel("Address");
	private  JTextField addr = new JTextField();
	private  JLabel emailL = new JLabel("Email");
	private  JTextField femail = new JTextField();
	private  JLabel totalL = new JLabel("Total Earnings");
	private  JTextField total = new JTextField();
	private  JButton btnReset = new JButton("Reset");
	private  JLabel upCropNameL = new JLabel("Crop Name");
	private  JTextField upCropName = new JTextField();
	private  JLabel upCropCostL = new JLabel("Cost");
	private  JTextField upCropCost = new JTextField();
	private  JLabel upCropQuanL = new JLabel("Quantity");
	private  JTextField upCropQuan = new JTextField();
	private  JLabel upCropWeightL = new JLabel("Weight");
	private  JLabel upCropAvaiL = new JLabel("Available");
	private  JTextField upCropWeight = new JTextField();
	private  JTextField upCropAvai = new JTextField();
	private  JLabel upCropPic = new JLabel("");
	private  JLabel label = new JLabel("Crop Name");
	private  JTextField c_name = new JTextField();
	private  JTextField c_cost = new JTextField();
	private  JLabel label_1 = new JLabel("Cost");
	private  JLabel c_pic = new JLabel("");
	private  JTextField c_quan = new JTextField();
	private  JLabel label_3 = new JLabel("Quantity");
	private  JLabel label_4 = new JLabel("Weight");
	private  JTextField c_wght = new JTextField();
	private  JTextField c_avail = new JTextField();
	private  JLabel label_5 = new JLabel("Available");
	private  JInternalFrame SalesPanel = new JInternalFrame("Sales",true,true,true,true);
	private  JInternalFrame allCropsPanel = new JInternalFrame("All Crops",true,true,true,true);
	private  JInternalFrame updateCropPanel = new JInternalFrame("Update Crops",true,true,true,true);
	private  JInternalFrame addCropPanel = new JInternalFrame("Add Crop",true,true,true,true);
	private JInternalFrame profilePanel = new JInternalFrame("Profile",true,true,true,true);
	
	
private static final String PHOTO_DIR = System.getProperty("user.dir") + File.separator + "photos" + File.separator;
private String currimage =  "profile.png";
private String background = "background.png";
private String usrpg = "userpage.jpg";
private String cartpic = "cart.png";
private String createpic = "createprofile";
private String photoPath = PHOTO_DIR+currimage ;
private String bgPath = PHOTO_DIR+background ;
private String userPath = PHOTO_DIR+usrpg ;
private String createPath = PHOTO_DIR+createpic;
private String cartPath = PHOTO_DIR+cartpic;


//farmer pics
private String salesimg =  "salesbg.jpg";
private String allcropsimg = "allcrops.jpg";
private String updatecropimg = "updatecrop.jpg";
private String addcropimg = "addcrop.jpg";
private String farmimg = "farmbg.png";
private String ppbg = "ppage.png";
private String salesPath = PHOTO_DIR+salesimg ;
private String allcropsPath = PHOTO_DIR+allcropsimg ;
private String upcropsPath = PHOTO_DIR+updatecropimg ;
private String addcropPath = PHOTO_DIR+addcropimg ;
private String farmwindowPath = PHOTO_DIR+farmimg ;
private String profilePath = PHOTO_DIR+ppbg ;

//private JLabel cartbg = new JLabel();
private JLabel wallpaper  = new JLabel();
private JLabel userbg  = new JLabel();
private JLabel createbg = new JLabel();
private JLabel salesbg  = new JLabel();
private JLabel allcropsbg  = new JLabel();
private JLabel updatecropsbg  = new JLabel();
private JLabel addcropbg  = new JLabel();
private JLabel farmbg  = new JLabel();
private JLabel ppagebg  = new JLabel();

private JDesktop mainwindow = new JDesktop () ;


public GUI(CustController cc, FarmController fc){
	
		super("Farmer's Market Application");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		mainwindow.setSize(700, 550);
		mainwindow.setLayout(null);
		add(mainwindow);
		wallpaper.setIcon(new ImageIcon(bgPath));
		userbg.setIcon(new ImageIcon(userPath));
		salesbg.setIcon(new ImageIcon(salesPath));
		allcropsbg.setIcon(new ImageIcon(allcropsPath));
		updatecropsbg.setIcon(new ImageIcon(upcropsPath));
		addcropbg.setIcon(new ImageIcon(addcropPath));
		farmbg.setIcon(new ImageIcon(farmwindowPath)); 
		ppagebg.setIcon(new ImageIcon(profilePath));
		createbg.setIcon(new ImageIcon(createPath));

		cartbutton.setIcon(new ImageIcon(cartPath));

		
		this.fc = fc;
		this.cc = cc;

		contentPane.setLayout(null);
		contentPane.setBounds(200, 200, 500, 455);

		contentPane.setContentPane(wallpaper);
		
		wallpaper.setVisible(true);
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(35, 88, 43, 27);
		contentPane.getContentPane().add(lblNewLabel_1);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPassword.setBounds(35, 126, 82, 27);
		contentPane.getContentPane().add(lblPassword);

		exitout = new JButton();
		exitout.setLocation(371, 264);
		exitout.setVisible(true);
		exitout.setText("Exit");
		exitout.setSize(96, 25);

		exitout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(new JFrame("Exit"), "Are you sure you want to Exit ?", " Logout",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
		contentPane.getContentPane().add(exitout);

		userSelect = new JComboBox<String>();
		userSelect.addItem("Customer");
		userSelect.addItem("Farmer");
		userSelect.setBounds(178, 205, 128, 20);
		contentPane.getContentPane().add(userSelect);

		emailField = new JTextField();
		emailField.setBounds(167, 92, 139, 23);
		contentPane.getContentPane().add(emailField);
		emailField.setColumns(10);

		passField = new JPasswordField();
		passField.setBounds(167, 130, 139, 20);
		contentPane.getContentPane().add(passField);
		passField.setColumns(10);

		submit = new JButton();
		submit.setText("Submit");
		submit.setBounds(48, 266, 89, 23);
		contentPane.getContentPane().add(submit);

		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {

					if (userSelect.getSelectedItem().equals("Farmer")) {
						String id = (String) emailField.getText();
						String pword = (String) passField.getText();

						boolean result = fc.loginCheck(id, pword);

						if (result == true) {
						//	contentPane.setVisible(false);
							passField.setText("");
							emailField.setText("");
							farmwindow.setVisible(true);
							System.out.println("Login Successful");
						} else {

							JOptionPane.showMessageDialog(new JFrame(),
									"Email and Password combination is incorrect. User not found.", "Invalid Login",
									JOptionPane.ERROR_MESSAGE);
						}
					}

					else {
						if (userSelect.getSelectedItem().equals("Customer")) {

							String id = (String) emailField.getText();
							String pword = (String) passField.getText();
							boolean result;
							result = cc.loginCheck(id, pword);

							if (result == true) {
							//	contentPane.setVisible(false);
								passField.setText("");
								emailField.setText("");
								contentPanelC.setVisible(true);
								System.out.println("Login Successful");
							} else {
								JOptionPane.showMessageDialog(new JFrame(),
										"Email and Password combination is incorrect. User not found.", "Invalid Login",
										JOptionPane.ERROR_MESSAGE);
							}
						}
					}

				} catch (NullPointerException er) {
					er.printStackTrace();
					JOptionPane.showMessageDialog(new JFrame(), "Email/Password cannot be blank.", "Invalid Entry",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		register = new JButton("Register");
		register.setBounds(200, 265, 89, 23);
		contentPane.getContentPane().add(register);

		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				passField.setText("");
				emailField.setText("");
				UserCreate.setVisible(true);
			}
		});

		mainwindow.add(contentPane);
		contentPane.setVisible(true);

		
		
																//CUSTOMER WINDOW
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 490, 348);
		contentPanelC.setBounds(200, 200, 750, 530);
		contentPanelC.setLayout(null);
		contentPanelC.setContentPane(userbg);
		contentPanelC.add(menuBarC);
		
		
		//contentPanelC.setSize(1200,600);
	cartbutton.setBounds(0, 0, 21, 21);

		menuBarC.setBounds(0, 0, 750, 22);
		
		menuBarC.add(ManageCropsC);
		ManageCropsC.add(ViewSomeC);
		ManageCropsC.add(ViewAllC);
		menuBarC.add(addFunds);
		menuBarC.add(cartbutton);
		
		menuBarC.add(mnProfileC);
		mnProfileC.add(mntmViewProfileC);
		mntmViewProfileC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contentPanelC.add(profilePanelC);
				profilePanelC.setVisible(true);

			}
		});
		mnLiveChat.add(mntmLiveChat);
		menuBarC.add(mnLiveChat);
		
		menuBarC.add(mnExitC);
		mnExitC.add(mntmLogoutC);
		mntmLogoutC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(new JFrame("Exit"), "Are you sure you want logout ?", " Logout",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					contentPanelC.remove(allCropsPanelC);
					contentPanelC.remove(profilePanelC);
					contentPanelC.setVisible(false);
					contentPane.setVisible(true);

				}
			}
		});
	menuBarC.setVisible(true);

		
		profilePanelC.setBounds(0, 22, 474, 287);
	//	profilePanelC.setContentPane(ppagebg);
		contentPanelC.add(profilePanelC);
				profilePanelC.setLayout(null);
				prPicC.setBounds(255, 63, 209, 170);

				profilePanelC.add(prPicC);
				fullnameC.setEditable(false);
				fullnameC.setBackground(UIManager.getColor("TextField.inactiveBackground"));
				// fullname.setColumns(10);
				fullnameC.setBounds(101, 63, 111, 20);

				profilePanelC.add(fullnameC);
				fullnameCL.setFont(new Font("Tahoma", Font.BOLD, 14));
				fullnameCL.setBounds(10, 66, 71, 14);

				profilePanelC.add(fullnameCL);
			
				emailCLC.setFont(new Font("Tahoma", Font.BOLD, 14));
				emailCLC.setBounds(10, 112, 46, 14);

				profilePanelC.add(emailCLC);
				emailC.setEditable(false);

				profilePanelC.add(emailC);
				totalCLC.setFont(new Font("Tahoma", Font.BOLD, 14));
				totalCLC.setBounds(10, 156, 110, 20);

				profilePanelC.add(totalCLC);

				profilePanelC.add(totalC);
				profilePanelC.setVisible(false);

		
		
		
		
		contentPanelC.setTitle("Customer Dashboard");
		
		mainwindow.add(contentPanelC);
		contentPanelC.setVisible(false);
																			//FARMER WINDOW
		farmwindow.setTitle("Farmer Dashboard");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// mainwindow.setBounds(200, 200, 780, 570);
		farmwindow.setBounds(200, 200, 750, 530);
		farmwindow.setContentPane(farmbg);
		farmwindow.setLayout(null);
		farmwindow.setJMenuBar(menuBar);
		profilePanel.setBounds(0, 22, 474, 287);
profilePanel.setContentPane(ppagebg);
		farmwindow.add(profilePanel);
		profilePanel.setLayout(null);
		prPic.setBounds(255, 63, 209, 170);

		profilePanel.add(prPic);
		fullname.setEditable(false);
		fullname.setBackground(UIManager.getColor("TextField.inactiveBackground"));
		// fullname.setColumns(10);
		fullname.setBounds(101, 63, 111, 20);

		profilePanel.add(fullname);
		fullnameL.setFont(new Font("Tahoma", Font.BOLD, 14));
		fullnameL.setBounds(10, 66, 71, 14);

		profilePanel.add(fullnameL);
		addrL.setFont(new Font("Tahoma", Font.BOLD, 14));
		addrL.setBounds(10, 197, 71, 14);

		profilePanel.add(addrL);

		profilePanel.add(addr);
		emailL.setFont(new Font("Tahoma", Font.BOLD, 14));
		emailL.setBounds(10, 112, 46, 14);

		profilePanel.add(emailL);
		femail.setEditable(false);

		profilePanel.add(femail);
		totalL.setFont(new Font("Tahoma", Font.BOLD, 14));
		totalL.setBounds(10, 156, 110, 20);

		profilePanel.add(totalL);

		profilePanel.add(total);
		profilePanel.setVisible(false);

		total.setEditable(false);
		total.setBounds(120, 153, 111, 20);
		total.setColumns(10);
		femail.setBackground(UIManager.getColor("TextField.inactiveBackground"));
		femail.setBounds(101, 109, 111, 20);
		// email.setColumns(10);
		addr.setEditable(false);
		addr.setBounds(101, 194, 111, 20);
		addr.setColumns(10);

		SalesPanel.setBounds(0, 22, 464, 287);
		SalesPanel.setContentPane(salesbg);
		farmwindow.add(SalesPanel);
		SalesPanel.setVisible(false);

		addCropPanel.setBounds(0, 22, 474, 287);

		farmwindow.add(addCropPanel);
		addCropPanel.setLayout(null);
		addCropPanel.setContentPane(addcropbg);
		cNameL.setFont(new Font("Tahoma", Font.BOLD, 14));

		cNameL.setBounds(10, 42, 95, 14);
		addCropPanel.add(cNameL);
		cName.setColumns(10);
		cName.setBounds(95, 39, 86, 20);
		addCropPanel.add(cName);

		cWeight.setColumns(10);
		cWeight.setBounds(95, 74, 86, 20);

		addCropPanel.add(cWeight);
		cWeightL.setFont(new Font("Tahoma", Font.BOLD, 14));
		cWeightL.setBounds(10, 77, 75, 14);

		addCropPanel.add(cWeightL);
		// cCost.setColumns(10);
		cCost.setBounds(95, 110, 86, 20);

		addCropPanel.add(cCost);
		cCostL.setFont(new Font("Tahoma", Font.BOLD, 14));
		cCostL.setBounds(10, 113, 75, 14);

		addCropPanel.add(cCostL);
		cQuanL.setFont(new Font("Tahoma", Font.BOLD, 14));
		cQuanL.setBounds(10, 153, 70, 14);

		addCropPanel.add(cQuanL);
		// cQuan.setColumns(10);
		cQuan.setBounds(95, 150, 86, 20);

		addCropPanel.add(cQuan);
		cBtnImg.setBounds(46, 225, 101, 23);

		addCropPanel.add(cBtnImg);
		cBtnImg.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				try {
					JFileChooser chooser = new JFileChooser();
					chooser.showOpenDialog(null);
					File f = chooser.getSelectedFile();
					String filename = f.getAbsolutePath();
					ImageIcon image = new ImageIcon(new ImageIcon(filename).getImage()
							.getScaledInstance(cPic.getWidth(), cPic.getHeight(), Image.SCALE_SMOOTH));
					cPic.setIcon(image);
				} catch (NullPointerException err) {
					err.printStackTrace();
					JOptionPane.showMessageDialog(new JFrame(), "Please upload a photo.", "No Image Found",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		cBtnSave.setBounds(177, 225, 89, 23);

		addCropPanel.add(cBtnSave);
		cPic.setBounds(250, 42, 186, 159);

		addCropPanel.add(cPic);
		btnReset.setBounds(303, 225, 89, 23);

		addCropPanel.add(btnReset);

		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cPic.getIcon() == null) {
				} else {
					cPic.setIcon(null);
				}
				cName.setText("");
				cCost.setText("");
				cWeight.setText("");
				cQuan.setText("");
			}
		});
		addCropPanel.setVisible(false);
		
		
		allCropsPanel.setBounds(0, 28, 474, 281);
		farmwindow.add(allCropsPanel);
		allCropsPanel.setLayout(null);
		allCropsPanel.setContentPane(allcropsbg);
		label.setFont(new Font("Tahoma", Font.BOLD, 14));
		label.setBounds(10, 36, 84, 14);

		allCropsPanel.add(label);
		c_name.setEditable(false);
		// c_name.setColumns(10);
		c_name.setBounds(119, 34, 86, 20);

		allCropsPanel.add(c_name);
		c_cost.setEditable(false);
		c_cost.setColumns(10);
		c_cost.setBounds(119, 77, 86, 20);

		allCropsPanel.add(c_cost);
		label_1.setFont(new Font("Tahoma",Font.BOLD, 14));
		label_1.setBounds(10, 79, 51, 14);

		allCropsPanel.add(label_1);
		c_pic.setBounds(264, 34, 176, 155);

		allCropsPanel.add(c_pic);
		c_quan.setEditable(false);
		c_quan.setColumns(10);
		c_quan.setBounds(119, 120, 86, 20);

		allCropsPanel.add(c_quan);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_3.setBounds(10, 123, 61, 14);

		allCropsPanel.add(label_3);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_4.setBounds(10, 161, 61, 25);

		allCropsPanel.add(label_4);
		c_wght.setEditable(false);
		c_wght.setColumns(10);
		c_wght.setBounds(119, 158, 86, 20);

		allCropsPanel.add(c_wght);
		c_avail.setEditable(false);
		c_avail.setColumns(10);
		c_avail.setBounds(119, 194, 86, 20);

		allCropsPanel.add(c_avail);
		label_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_5.setBounds(10, 197, 71, 14);

		allCropsPanel.add(label_5);
		allCropsPanel.setVisible(false);

		upCropAvai.setBounds(119, 193, 86, 20);
		upCropAvai.setColumns(10);
		upCropWeight.setBounds(119, 157, 86, 20);
		upCropWeight.setColumns(10);
		upCropQuan.setBounds(119, 119, 86, 20);
		upCropQuan.setColumns(10);
		upCropCost.setBounds(119, 76, 86, 20);
		upCropCost.setColumns(10);
		upCropName.setBounds(119, 33, 86, 20);
		upCropName.setColumns(10);

		updateCropPanel.setBounds(0, 22, 464, 287);
		contentPane.add(updateCropPanel);
		updateCropPanel.setLayout(null);
		updateCropPanel.setContentPane(updatecropsbg);
		upCropNameL.setFont(new Font("Tahoma", Font.BOLD, 14));
		upCropNameL.setBounds(10, 35, 84, 14);

		updateCropPanel.add(upCropNameL);

		updateCropPanel.add(upCropName);
		upCropCostL.setFont(new Font("Tahoma", Font.BOLD, 14));
		upCropCostL.setBounds(10, 78, 51, 14);

		updateCropPanel.add(upCropCostL);

		updateCropPanel.add(upCropCost);
		upCropQuanL.setFont(new Font("Tahoma", Font.BOLD, 14));
		upCropQuanL.setBounds(10, 122, 61, 14);

		updateCropPanel.add(upCropQuanL);

		updateCropPanel.add(upCropQuan);
		upCropWeightL.setFont(new Font("Tahoma", Font.BOLD, 14));
		upCropWeightL.setBounds(10, 160, 61, 14);

		updateCropPanel.add(upCropWeightL);
		upCropAvaiL.setFont(new Font("Tahoma", Font.BOLD, 14));
		upCropAvaiL.setBounds(10, 196, 71, 14);

		updateCropPanel.add(upCropAvaiL);

		updateCropPanel.add(upCropWeight);

		updateCropPanel.add(upCropAvai);
		upCropPic.setBounds(264, 33, 176, 155);

		updateCropPanel.add(upCropPic);

		JButton btnChgPic = new JButton("Change Pic");
		btnChgPic.setBounds(300, 209, 99, 23);
		updateCropPanel.add(btnChgPic);

		JButton btnSaveCrop = new JButton("Save");
		btnSaveCrop.setBounds(137, 247, 89, 23);
		updateCropPanel.add(btnSaveCrop);
		updateCropPanel.setVisible(false);
		menuBar.setBounds(0, 0, 750, 22);

		menuBar.add(mnManageCrops);

		mnManageCrops.add(mntmAddCrop);

		mntmAddCrop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				farmwindow.add(addCropPanel);
				addCropPanel.setVisible(true);
			}
		});

		mnManageCrops.add(mntmUpdateCrop);

		mntmUpdateCrop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				farmwindow.add(updateCropPanel);
				updateCropPanel.setVisible(true);

			}
		});

		mnManageCrops.add(mntmViewAllCrops);
		mntmViewAllCrops.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				farmwindow.add(allCropsPanel);
				allCropsPanel.setVisible(true);

			}
		});

		menuBar.add(mnSales);

		mnSales.add(mntmSalesMade);
		mntmSalesMade.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				farmwindow.add(SalesPanel);
				SalesPanel.setVisible(true);

			}
		});

		menuBar.add(mnProfile);

		mnProfile.add(mntmViewProfile);

		mntmViewProfile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				farmwindow.add(profilePanel);
				profilePanel.setVisible(true);

			}
		});

		menuBar.add(mnExit);

		mnExit.add(mntmLogout);

		mntmLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(new JFrame("Exit"), "Are you sure you want logout ?", " Logout",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					farmwindow.remove(SalesPanel);
					farmwindow.remove(allCropsPanel);
					farmwindow.remove(updateCropPanel);
					farmwindow.remove(addCropPanel);
					farmwindow.remove(profilePanel);
					farmwindow.setVisible(false);
					contentPane.setVisible(true);

				}
			}
		});

		

		mainwindow.add(farmwindow);
		farmwindow.setVisible(false);

		
		
		
		
		
		
																//CREATE USER WINDOW
		UserCreate.setBounds(200, 200, 655, 455);
		UserCreate.setLayout(null);
		UserCreate.setContentPane(createbg);
		UserCreate.setTitle("Account Creation");
		avatar = new JLabel();
		
		avatar.setIcon(new ImageIcon(photoPath));
		avatar.setBounds(349, 50, 230, 250);
		avatar.setVisible(true);
		UserCreate.add(avatar);

		address = new JTextField();
		address.setBounds(174, 313, 126, 20);
		address.setColumns(15);
		UserCreate.add(address);

		JLabel addressLabel = new JLabel("Address");
		addressLabel.setBounds(30, 315, 77, 14);
		addressLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		UserCreate.add(addressLabel);

		// THE BELOW CREATES BUTTONS AND TOGGLES ADDRESS ENTRY FROM VISIBLE TO INVISIBLE
		custRadio.setFont(new Font("Tahoma", Font.BOLD, 12));
		custRadio.setBounds(92, 30, 90, 35);
		custRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				address.setVisible(false);
				addressLabel.setText("");
				farmerRadio.setSelected(false);

			}
		});
		UserCreate.add(custRadio);

		farmerRadio.setBounds(205, 30, 80, 35);
		farmerRadio.setFont(new Font("Tahoma", Font.BOLD, 12));

		farmerRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				addressLabel.setText("Address");
				address.setVisible(true);
				custRadio.setSelected(false);

			}
		});
		UserCreate.add(farmerRadio);

		ButtonGroup group = new ButtonGroup();
		group.add(custRadio);
		group.add(farmerRadio);

		JButton uploadPic = new JButton("Upload Photo");
		uploadPic.setBounds(392, 312, 119, 23);
		uploadPic.setVisible(true);
		UserCreate.add(uploadPic);

		// adds profile pic
		uploadPic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					JFileChooser chooser = new JFileChooser();
					chooser.showOpenDialog(null);
					File f = chooser.getSelectedFile();
					String filename = f.getAbsolutePath();
					ImageIcon image = new ImageIcon(new ImageIcon(filename).getImage()
							.getScaledInstance(avatar.getWidth(), avatar.getHeight(), Image.SCALE_SMOOTH));
					avatar.setIcon(image);
				} catch (NullPointerException er) {
					er.printStackTrace();
					JOptionPane.showMessageDialog(new JFrame(), "Please upload a photo.", "No Image Found",
							JOptionPane.ERROR_MESSAGE);
				}

			}
		});

		JLabel fnameL = new JLabel("First Name");
		fnameL.setBounds(30, 90, 77, 14);
		fnameL.setFont(new Font("Tahoma", Font.BOLD, 14));
		UserCreate.add(fnameL);

		fname = new JTextField();
		fname.setBounds(174, 88, 126, 20);
		fnameL.setLabelFor(fname);
		UserCreate.add(fname);
		fname.setColumns(15);

		JLabel lnameL = new JLabel("Last Name");
		lnameL.setBounds(30, 145, 77, 14);
		lnameL.setFont(new Font("Tahoma", Font.BOLD, 14));
		UserCreate.add(lnameL);

		lname = new JTextField();
		lname.setBounds(174, 143, 126, 20);
		lnameL.setLabelFor(lname);
		lname.setColumns(15);
		UserCreate.add(lname);

		JLabel emailL = new JLabel("E-mail");
		emailL.setBounds(30, 200, 77, 14);
		emailL.setFont(new Font("Tahoma", Font.BOLD, 14));
		UserCreate.add(emailL);

		email = new JTextField();
		email.setBounds(174, 198, 126, 20);
		emailL.setLabelFor(email);
		email.setColumns(15);
		UserCreate.add(email);

		// SAVING USER ACTION
		JButton submit = new JButton("Create");
		submit.addMouseListener(new MouseAdapter() {

			// IF FARMER IS SELECTED IN RADIO BUTTON
			public void mouseClicked(MouseEvent e) {
				if (farmerRadio.isSelected()) {
					Farmer newFarmer = new Farmer((String) fname.getText(), (String) lname.getText(),
							(String) email.getText(), (String) pword.getText(), (String) address.getText(),
							avatar.getIcon());

					try {
						// existFarmers = fc.RetrieveUsers();// gets existing users and adds new user to
						// array
						// existFarmers.add(newFarmer);
						if (fc.save(newFarmer) == true) {
							JOptionPane.showMessageDialog(new JFrame(), "Your account has been created!",
									" User Created", JOptionPane.INFORMATION_MESSAGE);
							newFarmer.display();
							fname.setText("");
							lname.setText("");
							email.setText("");
							address.setText("");
							avatar.setIcon(null);
							avatar.setIcon(new ImageIcon(photoPath));
							pword.setText("");
							UserCreate.setVisible(false);

						} else {
							JOptionPane.showMessageDialog(new JFrame(), "There was an error creating your account ",
									" Account Not Created", JOptionPane.ERROR_MESSAGE);
						}

					} catch (NullPointerException e2) {
						e2.printStackTrace();

					}

				}

				// IF CUSTOMER IS SELECTED IN RADIO BUTTON

				if (custRadio.isSelected()) {
				//	ArrayList<User> existCust = new ArrayList<User>();
					User newCust = new User((String) fname.getText(), (String) lname.getText(),
							(String) email.getText(), (String) pword.getText(), avatar.getIcon());
					fname.setText("");
					lname.setText("");
					email.setText("");
					address.setText("");
					avatar.setIcon(null);
					avatar.setIcon(new ImageIcon(photoPath));
					avatar.setVisible(true);
					pword.setText("");

					try {
					//	existCust = cc.retreiveUsers();
					//	existCust.add(newCust);
						cc.save(newCust);

						JOptionPane.showMessageDialog(new JFrame(), "Your account has been created!", " User Created",
								JOptionPane.INFORMATION_MESSAGE);
					
					} catch (NullPointerException e2) {
						JOptionPane.showMessageDialog(new JFrame(), "There was an error creating your account ",
								" Account Not Created", JOptionPane.ERROR_MESSAGE);
						e2.printStackTrace();
					}

				}

			}
		});

		submit.setBounds(92, 357, 77, 23);
		UserCreate.add(submit);

		JButton back = new JButton("Cancel");
		back.setBounds(282, 357, 77, 23);
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fname.setText("");
				lname.setText("");
				email.setText("");
				address.setText("");
				avatar.setIcon(new ImageIcon(photoPath));
				avatar.setVisible(true);
				pword.setText("");
				UserCreate.setVisible(false);
				farmerRadio.setSelected(true);
				// contentPane.setVisible(true);
			}
		});
		UserCreate.add(back);

		JLabel pwordL = new JLabel("Password");
		pwordL.setFont(new Font("Tahoma", Font.BOLD, 14));
		pwordL.setBounds(30, 259, 77, 14);
		UserCreate.add(pwordL);

		pword = new JTextField();
		
		pword.setBounds(174, 256, 126, 20);
		UserCreate.add(pword);
		pword.setColumns(10);

		UserCreate.add(btnClear);

		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fname.setText("");
				lname.setText("");
				email.setText("");
				address.setText("");
				avatar.setIcon(new ImageIcon(photoPath));
				avatar.setVisible(true);
				pword.setText("");
			}
		});
		btnClear.setBounds(187, 357, 77, 23);
		btnClear.setVisible(true);
		mainwindow.add(UserCreate);
		UserCreate.setVisible(false);
		
		pack();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
	}

}