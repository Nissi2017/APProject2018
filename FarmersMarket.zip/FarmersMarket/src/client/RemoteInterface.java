package client;

import model.Farmer;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by Roberto Delfosse on 3/20/2018.
 */

interface RemoteInterface extends Remote{
    public int checkIfCustomerExists(String email, String password)throws RemoteException;
    public int checkIfFarmerExists(String email, String password)throws RemoteException;
    public Boolean registerFarmer(Farmer newFarmer) throws  RemoteException;
}