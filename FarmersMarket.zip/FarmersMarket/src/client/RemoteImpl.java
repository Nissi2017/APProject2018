package client;

import model.Farmer;

import javax.swing.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class RemoteImpl extends UnicastRemoteObject implements RemoteInterface{

    private static Connection con;

    RemoteImpl()throws RemoteException{

    }


    @Override
    public int checkIfCustomerExists(String email, String password) throws RemoteException {
        PreparedStatement ps = null;
        con = DbConnect.getDbConnect();
        try {
            ps = con.prepareStatement("select * from customer WHERE Email = '"+email+"' AND password = '"+password+"'");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int clientId = rs.getInt(1);
                System.out.println(clientId);
                return clientId;
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
       return -1;
    }
    @Override
    public int checkIfFarmerExists(String email, String password) throws RemoteException {
        PreparedStatement ps = null;
        con = DbConnect.getDbConnect();
        try {
            ps = con.prepareStatement("select * from farmer WHERE email = '"+email+"' AND password = '"+password+"'");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int clientId = rs.getInt(1);
                System.out.println(clientId);
                return clientId;
            } else {
                return -1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public Boolean registerFarmer(Farmer newFarmer) throws RemoteException {

        String SQL1 = "INSERT INTO `farmer`( `fullName`, `email`, `password`, `address`, `earnings`, `sellerLevel`) VALUES(?,?,?,?,?,?)";

        try {

            con = new DbConnect().getDbConnect();
            PreparedStatement preparedStatement1 = new DbConnect().getDbConnect().prepareStatement(SQL1);
            preparedStatement1.setString(1, newFarmer.getFname()+" "+newFarmer.getLname());
            preparedStatement1.setString(2, newFarmer.getEmail());
            preparedStatement1.setString(3, newFarmer.getPassword());
            preparedStatement1.setString(4, newFarmer.getAddress());
            preparedStatement1.setFloat(5, 0);
            preparedStatement1.setString(6, "1");
            preparedStatement1.execute();
            System.out.println("Inserted Farmer");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
    return false;
    }

}