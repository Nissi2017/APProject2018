package client;

import model.Farmer;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

/**
 * Created by Roberto Delfosse on 3/20/2018.
 */
public class Client {

    private RemoteInterface remote;

    public static void main(String args[])throws Exception{
       new Client().registerFarmer(null);
    }

    public Client() throws RemoteException, NotBoundException, MalformedURLException {
        remote = (RemoteInterface) Naming.lookup("rmi://localhost:3000/server");
    }

    public int customerLoginCheck(String email, String password) {
        int userExists = -1;
        try {
            userExists = remote.checkIfCustomerExists(email,password);
            return  userExists;

        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return  userExists;
    }
    public int farmerLoginCheck(String email, String password) {
        int userExists = -1;
        try {
            userExists = remote.checkIfFarmerExists(email,password);
            return  userExists;

        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return  userExists;
    }

    public boolean registerFarmer(Farmer newFarmer) {
        try {
           Boolean success = remote.registerFarmer(newFarmer);
            return  success;
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return false;
    }

}