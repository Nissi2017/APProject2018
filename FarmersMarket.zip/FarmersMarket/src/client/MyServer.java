package client;

import java.rmi.Naming;
import java.rmi.Remote;

public class MyServer {
    public static void main(String args[])throws Exception{
        Remote r = new RemoteImpl();
        Naming.rebind("rmi://localhost:3000/server",r);
    }
}