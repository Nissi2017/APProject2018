package controller;
/**
AUTHOR@author Sheckardo Daley
*/


import java.io.Serializable;

import model.User;

public class CustController  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private User cust = new User ();


	public boolean save(User newCust) {
		
	return cust.saveCust(newCust);
	}

	
	public boolean UserFileExists() {
	
		boolean result =	cust.UserFileExists()?  true :  false;
		
		return result;
	}





public boolean loginCheck(String email, String password) {
boolean result = cust.CustloginCheck(email, password)? true : false ;

return result;
	
}

}