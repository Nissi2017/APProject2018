package database;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import model.Customer;
import model.Farmer;

public class CustomerConnect extends InitDatabase<Customer> implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger logger = LogManager.getLogger(FarmerConnect.class);

	public static final String TABLE_NAME = "customer";

	public CustomerConnect() {
		super();
		
	} 
	
	
	
	

	@Override
	protected void initDatabase() {
		// TODO Auto-generated method stub
		try {
			statement = con.createStatement();
			if (statement
					.execute("create table if not exists "
							+ TABLE_NAME
							+ " (id INTEGER PRIMARY KEY AUTOINCREMENT, fullName varchar(45), email varchar(45), password varchar(20), address varchar(45), sellerLevel varchar(45), earnings FLOAT )")) {
				logger.debug("ITEM table created");
			} else {
				logger.debug("ITEM table does not need to be created");
			}
			logger.debug("ITEM table exists");
		} catch (SQLException e) {
			logger.error("Unable to initialize SQL Database", e);
		}
		
	}

	@Override
	public List<Customer> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}


	public boolean loginVerify(String email, String pass) {
		// TODO Auto-generated method stub
		Customer cust = null;
		try{
			statement = con.createStatement();
			String query = "select email, password from " + TABLE_NAME + " where email =  '" + email +"'" + " and password = '" + pass + "'" + ";";
			logger.debug("QUERY : "+query);
			result = statement.executeQuery(query);
			while(result.next()){
				cust = new Customer();
				cust.setEmail(result.getString(1)); // get ID column 1
				cust.setPassword(result.getString(2)); // get Name  2
			}
			
			if (email.equals(cust.getEmail()) && (pass.equals(cust.getPassword()))) {
				return true;
			}else {
				return false;
			}
		
			
		}catch(SQLException e){
			e.printStackTrace();
			logger.error("User Not Found "+email,e);
				
		}
		
		
		return false;
		
	}

	@Override
	public int update(Customer item, int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMultiple(int[] ids) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean userAdd(Customer cust) {
		// TODO Auto-generated method stub
		
		
		try{
			//cust.display();
			String query = "INSERT INTO "+TABLE_NAME
					       + "(fullName,email,password) VALUES (?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, cust.getFname() +" "+ cust.getLname());
			ps.setString(2, cust.getEmail());
			ps.setString(3, cust.getPassword());
			//ps.executeUpdate();
			
			return ps.executeUpdate() > 0 ;
					
    	}catch(SQLException e){
    		e.printStackTrace();
			logger.error("Unable to add Customer",e);
		}
		return false;
	}





	@Override
	public Customer get(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	

}
