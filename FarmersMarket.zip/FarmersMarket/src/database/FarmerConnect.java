package database;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import database.InitDatabase;
import model.Farmer;

public class FarmerConnect extends InitDatabase<Farmer> implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger logger = LogManager.getLogger(FarmerConnect.class);

	public static final String TABLE_NAME = "farmer";

	public FarmerConnect() {
		super();
		
	} 
	
	
	
	

	@Override
	protected void initDatabase() {
		// TODO Auto-generated method stub
		try {
			statement = con.createStatement();
			if (statement
					.execute("create table if not exists "
							+ TABLE_NAME
							+ " (id INTEGER PRIMARY KEY AUTOINCREMENT, fullName varchar(45), email varchar(45), password varchar(20), address varchar(45), sellerLevel varchar(45), earnings FLOAT )")) {
				logger.debug("ITEM table created");
			} else {
				logger.debug("ITEM table does not need to be created");
			}
			logger.debug("ITEM table exists");
		} catch (SQLException e) {
			logger.error("Unable to initialize SQL Database", e);
		}
		
	}

	@Override
	public List<Farmer> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Farmer get(int id) {
		// TODO Auto-generated method stub
		Farmer farmer = null;
		try{
			statement = con.createStatement();
			String query = "select * from "+TABLE_NAME+" where id = "+id+";";
			logger.debug("QUERY : "+query);
			result = statement.executeQuery(query);
			while(result.next()){
				farmer = new Farmer();
				//farmer.setId(result.getInt(1)); // get ID column 1
				//farmer.setName(result.getString(2)); // get Name  2
			}
			
			return farmer;
			
			
		}catch(SQLException e){
			logger.error("Unable to retrieve farmer with id "+id,e);
				
		}
		return farmer;
		
	}

	@Override
	public int update(Farmer item, int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMultiple(int[] ids) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean userAdd(Farmer farmer) {
		// TODO Auto-generated method stub
		
		
		try{
			//farmer.display();
			String query = "INSERT INTO "+TABLE_NAME
					       + "(fullName,email,password,address) VALUES (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, farmer.getFname() +" "+ farmer.getLname());
			ps.setString(2, farmer.getEmail());
			ps.setString(3, farmer.getPassword());
			ps.setString(4, farmer.getAddress());
			//ps.executeUpdate();
			
			return ps.executeUpdate() > 0 ;
					
    	}catch(SQLException e){
    		e.printStackTrace();
			logger.error("Unable to add farmer",e);
		}
		return false;
	}
	
	
	public boolean loginVerify(String email, String pass) {
		
		try{
			statement = con.createStatement();
			String query = "select email, password from " + TABLE_NAME + " where email =  '" + email +"'" + " and password = '" + pass + "'" + ";";
			logger.debug("QUERY : "+query);
			 result = statement.executeQuery(query);
Farmer farmer = null;
			while (result.next()) // while records were retrieved and unread
				// results
				{
					 farmer = new Farmer(); 
					farmer.setEmail(result.getString(1));
					farmer.setPassword(result.getString(2)); 
					}
			
			
			if (email.equals(farmer.getEmail()) && (pass.equals(farmer.getPassword()))) {
				return true;
			}else {
				return false;
			}
		
			
		}catch(SQLException e){
			e.printStackTrace();
			logger.error("User Not Found "+email,e);
				
		}
		
		
		return false;
		
	}
	
	
	

}
