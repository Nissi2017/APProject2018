package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class InitDatabase<M> {

	protected Connection con = null; 
	protected Statement statement = null;
	protected ResultSet result = null; 
	
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static Logger logger = LogManager.getLogger(InitDatabase.class);
	
	
	public InitDatabase() {
		
		try { 
			
			logger.trace("Attempting to connect to database, errors may occur");
			Class.forName(DRIVER).newInstance();
			
			
			String url = "jdbc:mysql://localhost:3306/Market";
			
			con = DriverManager.getConnection(url, "root", "chowder");
			
			initDatabase();
			
			logger.info("Connected to Database");
			logger.debug("Connected to Database");
			
			
		}catch (SQLException ex) {
			logger.error("Could not connect to database",ex);
		}// end catch
		catch (ClassNotFoundException ex) {
			logger.error("Failed to load JDBC/OBDC Driver",ex);
		}// end catch
		catch (NullPointerException ex) {
			logger.error("Could not find database",ex);
		}// end catch
		catch (IllegalAccessException ex) {
			logger.error("Unauthorized access to the database",ex);
		} catch (InstantiationException ex) {
			logger.error("Could not create instance of database",ex);
		}
		
	}


	abstract protected void initDatabase();
	   
	   abstract public List<M> selectAll();
	   
	   abstract public M get(int id);
	   
	   abstract public int update(M item, int id);
	   
	   abstract public int delete(int id);
	   
	   abstract public int deleteMultiple(int[] ids);
	   
	   abstract public boolean userAdd(M item);
	   
	
	
	
	
	
	
	
}
