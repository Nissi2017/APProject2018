package view;
/**
AUTHOR@author Sheckardo Daley
*/


import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import controller.CustController;
import controller.FarmController;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.UIManager;



public class FarmerDashboard extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private FarmController fc;
	private CustController cc;
	private JMenuBar menuBar = new JMenuBar();
	private JMenu mnManageCrops = new JMenu("Manage Crops");
	private JMenu mnProfile = new JMenu("Profile");
	private JMenu mnExit = new JMenu("Exit");
	private JMenu mnSales = new JMenu("Sales");
	private JMenuItem mntmSalesMade = new JMenuItem("Sales Made");
	private JMenuItem mntmAddCrop = new JMenuItem("Add Crop");
	private JMenuItem mntmUpdateCrop = new JMenuItem("Update Crop");
	private JMenuItem mntmViewAllCrops = new JMenuItem("View All Crops");
	private JMenuItem mntmViewProfile = new JMenuItem("View Profile");
	private JMenuItem mntmLogout = new JMenuItem("Logout");
	private JPanel addCropPanel = new JPanel();
	private JLabel cNameL = new JLabel("Crop Name");
	private JTextField cName = new JTextField();
	private JTextField cWeight = new JTextField();
	private JLabel cWeightL = new JLabel("Crop Weight");
	private JTextField cCost = new JTextField();
	private JLabel cCostL = new JLabel("Crop Cost");
	private JLabel cQuanL = new JLabel("Quantity");
	private JTextField cQuan = new JTextField();
	private JButton cBtnImg = new JButton("Add Image");
	private JButton cBtnSave = new JButton("Save");
	private JLabel cPic = new JLabel("");
	private JPanel profilePanel = new JPanel();
	private JLabel prPic = new JLabel("");
	private JTextField fullname = new JTextField();
	private JLabel fullnameL = new JLabel("Full Name");
	private JLabel addrL = new JLabel("Address");
	private  JTextField addr = new JTextField();
	private  JLabel emailL = new JLabel("Email");
	private  JTextField email = new JTextField();
	private String currEmail = null;
	private  JLabel totalL = new JLabel("Total Earnings");
	private  JTextField total = new JTextField();
	private  JButton btnReset = new JButton("Reset");

	/**
	 * Create the frame.
	 */
	public FarmerDashboard(String mail) {
		
	currEmail = mail;
		ConfigureLayout();
		configureActionListeners();
		
	}

	private void ConfigureLayout() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 490, 348);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		profilePanel.setBounds(0, 22, 474, 287);
		
				contentPane.add(profilePanel);
				profilePanel.setLayout(null);
				prPic.setBounds(255, 63, 209, 170);
				
						profilePanel.add(prPic);
						fullname.setEditable(false);
						fullname.setBackground(UIManager.getColor("TextField.inactiveBackground"));
						fullname.setColumns(10);
						fullname.setBounds(101, 63, 111, 20);
						
								profilePanel.add(fullname);
								fullnameL.setBounds(10, 66, 71, 14);
								
										profilePanel.add(fullnameL);
										addrL.setBounds(10, 197, 71, 14);
										
												profilePanel.add(addrL);
												
														profilePanel.add(addr);
														emailL.setBounds(10, 112, 46, 14);
														
																profilePanel.add(emailL);
																email.setEditable(false);
																
																profilePanel.add(email);
																totalL.setBounds(10, 156, 81, 14);
																
																profilePanel.add(totalL);
																
																profilePanel.add(total);
																profilePanel.setVisible(true);
																
																		total.setEditable(false);
																		total.setBounds(101, 153, 111, 20);
																		total.setColumns(10);
																		email.setBackground(UIManager.getColor("TextField.inactiveBackground"));
																		email.setBounds(101, 109, 111, 20);
																		email.setColumns(10);
																		addr.setEditable(false);
																		addr.setBounds(101, 194, 111, 20);
																		addr.setColumns(10);
		addCropPanel.setBounds(0, 22, 474, 287);

		contentPane.add(addCropPanel);
		addCropPanel.setLayout(null);

		cNameL.setBounds(10, 42, 75, 14);
		addCropPanel.add(cNameL);
		cName.setColumns(10);
		cName.setBounds(95, 39, 86, 20);
		addCropPanel.add(cName);

		cWeight.setColumns(10);
		cWeight.setBounds(95, 74, 86, 20);

		addCropPanel.add(cWeight);
		cWeightL.setBounds(10, 77, 75, 14);

		addCropPanel.add(cWeightL);
		cCost.setColumns(10);
		cCost.setBounds(95, 110, 86, 20);

		addCropPanel.add(cCost);
		cCostL.setBounds(10, 113, 75, 14);

		addCropPanel.add(cCostL);
		cQuanL.setBounds(10, 153, 54, 14);

		addCropPanel.add(cQuanL);
		cQuan.setColumns(10);
		cQuan.setBounds(95, 150, 86, 20);

		addCropPanel.add(cQuan);
		cBtnImg.setBounds(46, 225, 101, 23);

		addCropPanel.add(cBtnImg);
		cBtnSave.setBounds(177, 225, 89, 23);

		addCropPanel.add(cBtnSave);
		cPic.setBounds(250, 42, 186, 159);

		addCropPanel.add(cPic);
		btnReset.setBounds(303, 225, 89, 23);

		addCropPanel.add(btnReset);
		addCropPanel.setVisible(false);
		menuBar.setBounds(0, 0, 488, 21);

		menuBar.add(mnManageCrops);

		mnManageCrops.add(mntmAddCrop);

		mnManageCrops.add(mntmUpdateCrop);

		mnManageCrops.add(mntmViewAllCrops);

		menuBar.add(mnSales);

		mnSales.add(mntmSalesMade);

		menuBar.add(mnProfile);

		mnProfile.add(mntmViewProfile);

		menuBar.add(mnExit);

		mnExit.add(mntmLogout);
		contentPane.add(menuBar);
		
		contentPane.setVisible(true);

	}

	public void configureActionListeners() {
		mntmLogout.addActionListener(this);
		mntmViewProfile.addActionListener(this);
		mnSales.addActionListener(this);
		mntmAddCrop.addActionListener(this);
		mntmUpdateCrop.addActionListener(this);
		mntmViewAllCrops.addActionListener(this);
		cBtnImg.addActionListener(this);
		btnReset.addActionListener(this);
	}

	// tfarm@live.com
	public void actionPerformed(ActionEvent e) {

		//EXITS ACCOUNT
		if (e.getSource().equals(mntmLogout)) {

			if (JOptionPane.showConfirmDialog(new JFrame("Exit"), "Are you sure you want logout ?", " Logout",
					JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
				super.dispose();
				new Login(cc, fc);
			}
		}

		//BRINGS UP ADD CROP MENU
		if (e.getSource().equals(mntmAddCrop)) {
			profilePanel.setVisible(false);
			addCropPanel.setVisible(true);
		}
		
		if (e.getSource().equals(mntmViewProfile)) {
			email.setText(currEmail);
			profilePanel.setVisible(true);
			addCropPanel.setVisible(false);
		}

		//ADD CROP IMAGE
		if (e.getSource().equals(cBtnImg)) {
			JFileChooser chooser = new  JFileChooser();
			chooser.showOpenDialog(null);
			File f = chooser.getSelectedFile();
			String filename = f.getAbsolutePath();
ImageIcon image = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(cPic.getWidth(), 
		cPic.getHeight(), Image.SCALE_SMOOTH));
cPic.setIcon(image);
		}
if (e.getSource().equals(btnReset)) {
 if (cPic.getIcon() == null) { 
 			} else {
	 cPic.setIcon(null);
 				}
	cName.setText("");
	cCost.setText("");
	cWeight.setText("");
	cQuan.setText("");
	
}

	
	}




}
