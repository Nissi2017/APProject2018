package view;
/**
AUTHOR@author Sheckardo Daley
*/



import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

import controller.CustController;
import controller.FarmController;


public class Login extends JFrame 
implements ActionListener{
	
	private static final long serialVersionUID = 1L;
	private JFrame contentPane;
	private JTextField emailField ;
	private JTextField passField ;
	private JComboBox<String> userSelect ;
	private JButton submit ;
	private JButton exit;
	private CustController cc;
	private FarmController fc;
	private JButton register;

	
	
	public Login(CustController cc, FarmController fc){
		super("Farmer's Market Application");
		this.fc = fc;
		this.cc=cc;
		viewLayout();
		configureActionListeners();
	}
		
	
	private void viewLayout() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 551, 352);
		contentPane = new JFrame();
		contentPane.getContentPane().setLayout(null);
		contentPane.setSize(500, 350);
		JLabel lblNewLabel = new JLabel("              LOGIN MENU");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(160, 11, 203, 40);
		contentPane.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(35, 88, 43, 27);
		contentPane.getContentPane().add(lblNewLabel_1);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPassword.setBounds(35, 126, 82, 27);
		contentPane.getContentPane().add(lblPassword);
		
		exit = new JButton(); 
		exit.setLocation(371, 264);
		exit.setVisible(true);
		exit.setText("Exit");
		exit.setSize(96, 25);
		contentPane.getContentPane().add(exit);
		
		userSelect=new JComboBox<String>();
		userSelect.addItem("Customer");
		userSelect.addItem("Farmer");
		userSelect.setBounds(178, 205, 128, 20);
		contentPane.getContentPane().add(userSelect);
		
	
		emailField = new JTextField();
		emailField.setBounds(167, 92, 139, 23);
		contentPane.getContentPane().add(emailField);
		emailField.setColumns(10);
		
		passField = new JTextField();
		passField.setBounds(167, 130, 139, 20);
		contentPane.getContentPane().add(passField);
		passField.setColumns(10);
		
		submit = new JButton();
		submit.setText("Submit");
		submit.setBounds(48, 266, 89, 23);
		contentPane.getContentPane().add(submit);
		
		register = new JButton("Register");
		register.setBounds(200, 265, 89, 23);
		contentPane.getContentPane().add(register);
		
		contentPane.setVisible(true);
	
	}

	public void configureActionListeners(){
		submit.addActionListener(this);
		exit.addActionListener(this);
		register.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		// SEARCHES FILE FOR USER LOGIN (FARMER)
		if (e.getSource().equals(submit)) {
			if (userSelect.getSelectedItem().equals("Farmer")) {
				String id = (String) emailField.getText();
				String pword = (String) passField.getText();
				boolean result ;
			result =fc.FarmerloginCheck(id, pword);
						// JOptionPane.showMessageDialog(this, "Logging in as " + alf.get(d).getFname()
						if (result == true) { contentPane.dispose();
						new FarmerDashboard().setVisible(true);
						}
			} else {
				if (userSelect.getSelectedItem().equals("Customer")) {
					String id = (String) emailField.getText();
					String pword = (String) passField.getText();
					boolean result ;
				result =cc.CustloginCheck(id, pword);
							// JOptionPane.showMessageDialog(this, "Logging in as " + alf.get(d).getFname()
							if (result == true) { 
								contentPane.dispose();
							new FarmerDashboard().setVisible(true);
							}
					}
				}
			}

		

		// WHEN EXIT IS SELECTED
		if (e.getSource().equals(exit)) {
			if (JOptionPane.showConfirmDialog(new JFrame("Exit"), "Are you sure you want to Exit ?", " Logout",
					JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
				System.exit(0);
			}
		}

		// REGISTER
		if (e.getSource().equals(register)) {
			contentPane.dispose();
			new UserCreation();

		}

	}

}