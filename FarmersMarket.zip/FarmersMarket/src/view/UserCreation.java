package view;


import javax.swing.JFrame;

import model.Farmer;
import model.User;
import java.awt.Image;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import controller.CustController;
import controller.FarmController;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;


public class UserCreation extends JFrame 
	implements ActionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	private JFrame contentPane;
	private JTextField fname;
	private JTextField lname;
	private JTextField email;
	private JTextField address;
	private JRadioButton custRadio = new JRadioButton("Customer");
	private JRadioButton farmerRadio = new JRadioButton("Farmer",true);
	private CustController cc = new CustController ();
	private FarmController fc = new FarmController();
	private JLabel avatar;
	private JTextField pword;
	
	public UserCreation() {
super("Create A User");
		 ConfigureView() ;
		
		
	}

	private void ConfigureView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 541, 408);
		contentPane = new JFrame();
		contentPane.setSize(550, 460);
		contentPane.getContentPane().setLayout(null);

		avatar = new JLabel();
		avatar.setBounds(349, 90, 119, 127);
		avatar.setVisible(true);
		contentPane.getContentPane().add(avatar);

		address = new JTextField();
		address.setBounds(174, 313, 126, 20);
		address.setColumns(15);
		contentPane.getContentPane().add(address);

		JLabel addressLabel = new JLabel("Address");
		addressLabel.setBounds(30, 315, 50, 15);
		addressLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.getContentPane().add(addressLabel);

		// THE BELOW CREATES BUTTONS AND TOGGLES ADDRESS ENTRY FROM VISIBLE TO INVISIBLE
		custRadio.setFont(new Font("Tahoma", Font.PLAIN, 12));
		custRadio.setBounds(92, 30, 77, 23);
		custRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				address.setVisible(false);
				addressLabel.setText(null);
				farmerRadio.setSelected(false);

			}
		});
		contentPane.getContentPane().add(custRadio);

		farmerRadio.setBounds(205, 30, 63, 23);
		farmerRadio.setFont(new Font("Tahoma", Font.PLAIN, 12));

		farmerRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				addressLabel.setText("Address");
				address.setVisible(true);
				custRadio.setSelected(false);

			}
		});
		contentPane.getContentPane().add(farmerRadio);

		ButtonGroup group = new ButtonGroup();
		group.add(custRadio);
		group.add(farmerRadio);

		JButton uploadPic = new JButton("Upload Photo");
		uploadPic.setBounds(392, 312, 119, 23);
		contentPane.getContentPane().add(uploadPic);
		uploadPic.setVisible(true);

		// adds profile pic
		uploadPic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File f = chooser.getSelectedFile();
				String filename = f.getAbsolutePath();
				ImageIcon image = new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(avatar.getWidth(),
						avatar.getHeight(), Image.SCALE_SMOOTH));
				avatar.setIcon(image);

			}
		});

		JLabel fnameL = new JLabel("First Name");
		fnameL.setBounds(30, 90, 57, 15);
		fnameL.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.getContentPane().add(fnameL);

		fname = new JTextField();
		fname.setBounds(174, 88, 126, 20);
		fnameL.setLabelFor(fname);
		contentPane.getContentPane().add(fname);
		fname.setColumns(15);

		JLabel lnameL = new JLabel("Last Name");
		lnameL.setBounds(30, 145, 57, 15);
		lnameL.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.getContentPane().add(lnameL);

		lname = new JTextField();
		lname.setBounds(174, 143, 126, 20);
		lnameL.setLabelFor(lname);
		lname.setColumns(15);
		contentPane.getContentPane().add(lname);

		JLabel emailL = new JLabel("E-mail");
		emailL.setBounds(30, 200, 31, 15);
		emailL.setFont(new Font("Tahoma", Font.PLAIN, 12));
		contentPane.getContentPane().add(emailL);

		email = new JTextField();
		email.setBounds(174, 198, 126, 20);
		emailL.setLabelFor(email);
		email.setColumns(15);
		contentPane.getContentPane().add(email);

		// SAVING USER ACTION
		JButton submit = new JButton("Create");

		submit.addMouseListener(new MouseAdapter() {

			
			// IF FARMER IS SELECTED IN RADIO BUTTON
			public void mouseClicked(MouseEvent e) {
				if (farmerRadio.isSelected()) {

					ArrayList<Farmer> existFarmers = new ArrayList<Farmer>();

					Farmer newFarmer = new Farmer((String) fname.getText(), (String) lname.getText(),
							(String) email.getText(), (String) pword.getText(), (String) address.getText(),
							avatar.getIcon());

					try {
						existFarmers = fc.getUsers();// gets existing users and adds new user to array
						existFarmers.add(newFarmer);
						fc.saveFarmer(existFarmers);
						for (int d = 0; d < existFarmers.size(); d++) {
							existFarmers.get(d).display();
						}
						System.out.println("User Created");
						contentPane.dispose();
						new Login(cc, fc);

					} catch (NullPointerException e2) {
						System.out.println("Error Creating User");
						contentPane.dispose();
						new Login(cc, fc);
					}

				}

				// IF CUSTOMER IS SELECTED IN RADIO BUTTON

				if (custRadio.isSelected()) {
					ArrayList<User> existCust = new ArrayList<User>();
					User newCust = new User((String) fname.getText(), (String) lname.getText(),
							(String) email.getText(), (String) pword.getText(), avatar.getIcon());

					try {
						existCust = cc.getUsers();
						existCust.add(newCust);
						cc.saveCust(existCust);

						for (int d = 0; d < existCust.size(); d++) {
							existCust.get(d).display();
						}

						System.out.println("User Created");
						contentPane.dispose();
						new Login(cc, fc).setVisible(true);
					} catch (NullPointerException e2) {
						System.out.println("Error Creating User");
						contentPane.dispose();
						new Login(cc, fc);
					}

				}

			}
		});

		submit.setBounds(92, 357, 77, 23);
		contentPane.getContentPane().add(submit);

		JButton back = new JButton("Cancel");
		back.setBounds(282, 357, 77, 23);
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				contentPane.dispose();
				new Login(cc, fc);
			}
		});
		contentPane.getContentPane().add(back);

		JLabel pwordL = new JLabel("Password");
		pwordL.setFont(new Font("Tahoma", Font.PLAIN, 12));
		pwordL.setBounds(30, 259, 77, 14);
		contentPane.getContentPane().add(pwordL);

		pword = new JTextField();
		pword.setFont(new Font("Tahoma", Font.PLAIN, 12));
		pword.setBounds(174, 256, 126, 20);
		contentPane.getContentPane().add(pword);
		pword.setColumns(10);
		contentPane.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}
}
