package model;

import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JCheckBox;

public class FarmerVM extends Farmer {

	/*private static final long serialVersionUID = 1L;
	private JCheckBox chkInUse;

	public FarmerVM(String fname, String lname, String email,String password, String addy, Icon img) {
		
		super(fname,lname,email,password,addy, img);
		
	}

	public FarmerVM(int id, String name) {
		super(id, name);
		chkInUse = new JCheckBox();
		chkInUse.setToolTipText("Select " + name);
		chkInUse.setName(id + "");
	}

	public FarmerVM(Farmer m) {
		this(m.getId(), m.getName());
	}

	public boolean isSelected() {
		return chkInUse.isSelected();
	}

	public void addActionListener(ActionListener al) {
		chkInUse.addActionListener(al);
	}

	public JCheckBox getCheckBoxInUse() {
		return chkInUse;
	}

	public Object[] toObjectArray() {
		return new Object[] { getId(), getName(), "Farmer",
				new Boolean(chkInUse.isSelected()) };
	}

	public void setValueAtIndex(int index, Object value) {
		switch (index) {
		case 0: // this is the id - do nothing
			break;
		case 1:
			setName((String) value);
			break;
		case 2: // this is the type - do nothing
			break;
		case 3:
			chkInUse.setSelected((Boolean) value);
			break;
		}
	}*/

}