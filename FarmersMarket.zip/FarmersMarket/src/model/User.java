package model;
/**
AUTHOR@author Sheckardo Daley
*/

import java.io.Serializable;
import javax.swing.Icon;


@SuppressWarnings("serial")
public class User implements Serializable{

	protected String fname;
	protected String lname ;
	protected String email;
	protected String password;
	protected Icon img ;
	
	public User () {
		fname = "Blank first name";
		lname = "Blank last name";
		email = "Blank email";
		password = "Blank password";
	}
	
	public User (String inFname, String inLname, String inEmail, String inPassword,Icon Inimg) {
	
		fname = inFname;
		lname = inLname;
		email = inEmail;
		password = inPassword;
		img = Inimg;
	}
	
	public User (User inUser) {
		fname = inUser.fname;
		lname = inUser.lname;
		email = inUser.email;
		password = inUser.password;
	img = inUser.img;
	}
	
	public String getFname() {
		return fname;
	}
	public String getLname() {
		return lname;
	}
	public String getEmail() {
		return email;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Icon getImg() {
		return img;
	}
	public void setImg(Icon img) {
		this.img = img;
	}
	public void display () {
		System.out.println("\n" + fname + " " + lname);
		System.out.println(email);
		System.out.println(password);
	}	
	
	
}
