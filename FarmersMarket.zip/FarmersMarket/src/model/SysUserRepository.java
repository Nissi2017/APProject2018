package model;
/**
AUTHOR@author Sheckardo Daley
*/

import java.util.ArrayList;

public interface SysUserRepository<u>{

	void saveFarmer (ArrayList<Farmer> u);
	
	void saveCust(ArrayList<User> u);
	
	ArrayList<u> getUsers();
	
	boolean UserFileExists () ;
	
}
