package model;
/**
AUTHOR@author Sheckardo Daley
*/

import java.util.ArrayList;

public interface SysUserRepository<u>{

	void saveFarmer (ArrayList<Farmer> u);
	
	void saveCust(ArrayList<User> u);
	
	boolean FarmerloginCheck(String email,String password);
	
	boolean CustloginCheck(String email,String password);
	
	ArrayList<u> getUsers();
	
	boolean UserFileExists () ;
	
}
