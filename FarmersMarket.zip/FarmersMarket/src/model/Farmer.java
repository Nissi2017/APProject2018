package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import javax.swing.Icon;
import database.FarmerConnect;
@SuppressWarnings("serial")
public class Farmer extends User implements Serializable{
	
//	FarmerConnect connect = new FarmerConnect();

	private String address;
	
	public Farmer () {
		super();
		address = "Blank address";	
	}

	public Farmer(String fname, String lname, String email,String password, String addy, Icon img) {
		
		super(fname,lname,email,password,img);
		address = addy ;

	
	}

	public Farmer(Farmer inFarmer) {
		address = inFarmer.address;
		fname = inFarmer.fname;
		lname = inFarmer.lname;
		email = inFarmer.email;
		password = inFarmer.password;
		img = inFarmer.img;
	}
	

	

	
public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	public boolean UserFileExists() {

		File yourFile = new File("farmers.dat");
		 // if file already exists will do nothing 
	
		if(yourFile.exists() == false) {
			try {
			yourFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(yourFile, false); 
			fos.close();		
			return false;
			} catch (IOException e) {
			e.printStackTrace();	
				}
			} else {
				return true;
			}
	return true;
	}

	
public void display () {
	System.out.println("\n" + fname + " " + lname);
	System.out.println(email);
	System.out.println(password);
	System.out.println(address);
}

public void add(Farmer newFarmer) {
	// TODO Auto-generated method stub
	
}	
}

