package model;

import java.io.Serializable;

import javax.swing.Icon;
@SuppressWarnings("serial")
public class Farmer extends User implements Serializable{

	private String address;
	
	public Farmer () {
		super();
		address = "Blank address";	
	}

	public Farmer(String fname, String lname, String email,String password, String addy, Icon img) {
		
		super(fname,lname,email,password,img);
		address = addy ;

	
	}

	public Farmer(Farmer inFarmer) {
		address = inFarmer.address;
		fname = inFarmer.fname;
		lname = inFarmer.lname;
		email = inFarmer.email;
		password = inFarmer.password;
		img = inFarmer.img;
	}
	

	

	
public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

public void display () {
	System.out.println("\n" + fname + " " + lname);
	System.out.println(email);
	System.out.println(password);
	System.out.println(address);
}	
}
