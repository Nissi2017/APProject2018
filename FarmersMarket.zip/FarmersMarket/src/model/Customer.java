package model;

import javax.swing.Icon;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import database.CustomerConnect;

public class Customer extends User{
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

private static Logger logger = LogManager.getLogger(Farmer.class);
	
	CustomerConnect connect = new CustomerConnect();

	private String address;
	
	public Customer() {
		super();
		address = "Blank address";	
	}

	public Customer(String fname, String lname, String email,String password, Icon img) {
		
		super(fname,lname,email,password,img);

	
	}

	public Customer(Customer incust) {
		fname = incust.fname;
		lname = incust.lname;
		email = incust.email;
		password = incust.password;
		img = incust.img;
	}
	


	public boolean saveCust(Customer newCust) {
		
		return connect.userAdd(newCust);

		
		/*UserFileExists();
		ObjectOutputStream oos = null;

		try {
			FileOutputStream fos = new FileOutputStream("farmers.dat");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(newFarmer);
			System.out.println("Object Saved");
			return true;
		}catch (IOException e) {
		
			e.printStackTrace();
		}
		
		finally {
			try { if (oos != null)
				oos.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}	
	return false;*/
		
		
	}
	
	/*public boolean UserFileExists() {

		File yourFile = new File("farmers.dat");
		 // if file already exists will do nothing 
	
		if(yourFile.exists() == false) {
			try {
			yourFile.createNewFile();
		FileOutputStream fos = new FileOutputStream(yourFile, false); 
			fos.close();		
			return false;
			} catch (IOException e) {
			e.printStackTrace();	
				}
			} else {
				return true;
			}
	return true;
	}*/

	public boolean FarmerloginCheck(String email, String password) {
		try {

			return connect.loginVerify(email, password);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Login Failed!");
			logger.debug("Incorrect Login information");
			return false;
		}
		
		/*boolean res =	UserFileExists();
		boolean found = false;
		Farmer f= new Farmer();
		if (res == true) {
		
			ObjectInputStream ois = null;

			try {
				try {
				FileInputStream fis = new FileInputStream("farmers.dat");
				ois = new ObjectInputStream(fis);
				} catch(FileNotFoundException fe) {
					fe.printStackTrace();
				}
				try {
			
				f = (Farmer)ois.readObject(); //ARRAY IS RECEIVED AND CONVERTED TO ARRAY OF FARMERS
				if (f.getEmail().equals(email) && f.getPassword().equals(password)) 
				{
					found = true;
					return found;
					}
				
				
				}
				
				catch (ClassCastException | ClassNotFoundException ce) {
					ce.printStackTrace();
				}
			
		
			}
			
			catch (IOException e) {
			
				e.printStackTrace();
			}
			
			finally {
				try { if (ois != null)
					ois.close();
			
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
				return found;
		} else {
			
		}
//		Farmer farmers = new Farmer ();
//		return farmers ;
		return found;    */
	
	}

	
	
public void display () {
	System.out.println("\n" + fname + " " + lname);
	System.out.println(email);
	System.out.println(password);
	System.out.println(address);
}

public void add(Farmer newFarmer) {
	// TODO Auto-generated method stub
	
}
	

}
