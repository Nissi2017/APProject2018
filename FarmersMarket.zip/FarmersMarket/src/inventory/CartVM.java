package inventory;

public class CartVM  {
	
	

}
